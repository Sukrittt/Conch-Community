document.getElementById("join-us").addEventListener("click", function (e) {
  alert("Under Construction");
});
document.getElementById("s1").addEventListener("click", function (e) {
  alert("Under Construction");
});
document.getElementById("s2").addEventListener("click", function (e) {
  alert("Under Construction");
});
document.getElementById("s3").addEventListener("click", function (e) {
  alert("Under Construction");
});
document.getElementById("s4").addEventListener("click", function (e) {
  alert("Under Construction");
});
document.getElementById("s5").addEventListener("click", function (e) {
  alert("Under Construction");
});
